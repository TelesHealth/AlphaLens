#!/bin/bash
# ============================================================
#  Alpha Lens — E8 Market Radar Engine
#  Run from Replit Shell: bash install_e8_radar.sh
#
#  Adds:
#  - Real-time price spike detection (WebSocket + polling)
#  - Volume anomaly monitoring (unusual volume flags)
#  - Cross-asset chain reaction triggers
#  - /radar page in the frontend
#  - /api/radar endpoints
#  - Radar scan job every 5 minutes
# ============================================================

set -e

echo ""
echo "============================================"
echo "  Alpha Lens — E8 Market Radar Engine"
echo "============================================"
echo ""

if [ ! -f "backend/main.py" ]; then
  echo "ERROR: Run from your Replit root directory."
  exit 1
fi

echo "[1/7] Creating E8 Market Radar engine..."

cat > backend/engines/market_radar.py << 'PYEOF'
"""
E8: Market Radar Engine
Detects real-time price spikes, unusual volume, and triggers
cross-asset chain reaction alerts.

Runs every 5 minutes via APScheduler.
WebSocket connections for crypto (Coinbase) and stocks (Alpaca)
provide tick-level data between polls.

Data sources (free tier):
  - Alpaca WebSocket  → US stocks/ETFs real-time
  - Coinbase WebSocket → Crypto real-time  
  - yfinance polling   → Commodities, indices (15min delay)
  - Polymarket CLOB   → Prediction market prices
  - Kalshi REST       → Prediction market prices

Optional paid sources (add API keys to unlock):
  - Unusual Whales    → Options flow anomalies (UNUSUAL_WHALES_KEY)
  - Alpha Vantage     → Real-time commodity quotes (ALPHA_VANTAGE_KEY)
  - Finnhub           → News + earnings calendar (FINNHUB_KEY)
"""
import asyncio
import httpx
import json
import hashlib
from datetime import datetime, timedelta
from typing import Optional
from backend.db.database import get_db, get_cache
from backend.config import settings

# ── Spike detection thresholds ────────────────────────────────────────────
# Format: asset_id -> { pct_threshold, window_minutes, severity }
SPIKE_THRESHOLDS = {
    # Energy
    "brent_crude":      {"pct": 2.0,  "window": 15, "severity": "critical"},
    "wti_crude":        {"pct": 2.0,  "window": 15, "severity": "critical"},
    "ttf_gas":          {"pct": 3.0,  "window": 15, "severity": "critical"},
    "natural_gas":      {"pct": 3.0,  "window": 15, "severity": "high"},
    "coal":             {"pct": 3.0,  "window": 30, "severity": "high"},
    # Metals
    "gold":             {"pct": 1.5,  "window": 30, "severity": "high"},
    "silver":           {"pct": 2.5,  "window": 30, "severity": "high"},
    "copper":           {"pct": 2.0,  "window": 20, "severity": "high"},
    # Crypto
    "crypto_btc":       {"pct": 3.0,  "window": 15, "severity": "high"},
    "crypto_eth":       {"pct": 4.0,  "window": 15, "severity": "high"},
    "crypto_sol":       {"pct": 5.0,  "window": 15, "severity": "medium"},
    # Equities
    "stock_spy":        {"pct": 1.0,  "window": 10, "severity": "high"},
    "stock_qqq":        {"pct": 1.2,  "window": 10, "severity": "high"},
    "stock_xle":        {"pct": 2.0,  "window": 20, "severity": "medium"},
    # Agriculture
    "wheat":            {"pct": 2.0,  "window": 20, "severity": "high"},
    "corn":             {"pct": 2.5,  "window": 20, "severity": "medium"},
    "soybeans":         {"pct": 2.5,  "window": 20, "severity": "medium"},
    # FX
    "eurusd":           {"pct": 0.5,  "window": 30, "severity": "high"},
    "usdjpy":           {"pct": 0.5,  "window": 30, "severity": "high"},
}

# ── Chain reaction map ────────────────────────────────────────────────────
# When asset X spikes, flag these downstream assets for review
CHAIN_REACTIONS = {
    "brent_crude": [
        {"asset": "wti_crude",        "direction": "bull", "confidence": 95, "reason": "Direct correlation — same supply shock"},
        {"asset": "stock_xle",        "direction": "bull", "confidence": 82, "reason": "Energy sector ETF moves with oil prices"},
        {"asset": "airlines",         "direction": "bear", "confidence": 88, "reason": "Fuel cost spike → margin pressure, typically -1.5 to -3% equity move"},
        {"asset": "ttf_gas",          "direction": "bull", "confidence": 70, "reason": "Energy complex correlated — European inflation signal"},
        {"asset": "nok_usd",          "direction": "bull", "confidence": 68, "reason": "Norway major oil exporter — NOK strengthens on oil price"},
        {"asset": "cad_usd",          "direction": "bull", "confidence": 65, "reason": "Canada oil sands producer — CAD is oil proxy currency"},
        {"asset": "poly_fed_cut",     "direction": "bear", "confidence": 52, "reason": "Oil spike raises inflation expectations → reduces Fed cut probability"},
    ],
    "wti_crude": [
        {"asset": "brent_crude",      "direction": "bull", "confidence": 93, "reason": "Tight spread correlation"},
        {"asset": "stock_uso",        "direction": "bull", "confidence": 88, "reason": "USO ETF directly tracks WTI"},
        {"asset": "airlines",         "direction": "bear", "confidence": 85, "reason": "Direct fuel cost impact"},
    ],
    "ttf_gas": [
        {"asset": "brent_crude",      "direction": "bull", "confidence": 65, "reason": "European energy complex"},
        {"asset": "eur_usd",          "direction": "bear", "confidence": 70, "reason": "Energy import costs weaken EUR"},
        {"asset": "german_equities",  "direction": "bear", "confidence": 75, "reason": "DAX industrial sector hit by energy costs"},
        {"asset": "coal",             "direction": "bull", "confidence": 68, "reason": "Gas substitution demand — coal as backup"},
    ],
    "crypto_btc": [
        {"asset": "crypto_eth",       "direction": "bull", "confidence": 88, "reason": "BTC leads altcoin moves — high beta"},
        {"asset": "crypto_sol",       "direction": "bull", "confidence": 82, "reason": "Alt season correlation"},
        {"asset": "gold",             "direction": "mixed", "confidence": 55, "reason": "Both store of value — sometimes correlated, sometimes inverse"},
        {"asset": "stock_spy",        "direction": "bull", "confidence": 58, "reason": "Risk-on correlation has strengthened since 2023"},
    ],
    "stock_spy": [
        {"asset": "stock_qqq",        "direction": "bull", "confidence": 92, "reason": "Tight S&P/NASDAQ correlation"},
        {"asset": "gold",             "direction": "bear", "confidence": 62, "reason": "Risk-on reduces safe haven demand"},
        {"asset": "usdjpy",           "direction": "bull", "confidence": 65, "reason": "Equity strength often accompanies risk-on FX moves"},
        {"asset": "vix",              "direction": "bear", "confidence": 80, "reason": "SPY up = VIX typically down"},
    ],
    "wheat": [
        {"asset": "corn",             "direction": "bull", "confidence": 72, "reason": "Feed grain substitution — correlated supply shocks"},
        {"asset": "soybeans",         "direction": "bull", "confidence": 65, "reason": "Agricultural complex correlation"},
        {"asset": "black_sea_freight","direction": "bull", "confidence": 70, "reason": "Grain shipping demand increases"},
        {"asset": "egypt_egp",        "direction": "bear", "confidence": 68, "reason": "Egypt is world's largest wheat importer — currency pressure"},
    ],
    "gold": [
        {"asset": "silver",           "direction": "bull", "confidence": 85, "reason": "Precious metals complex — silver follows gold with higher beta"},
        {"asset": "usd_dxy",          "direction": "bear", "confidence": 72, "reason": "Gold inversely correlated to dollar strength"},
        {"asset": "real_yields",      "direction": "bear", "confidence": 75, "reason": "Gold rises when real yields fall"},
        {"asset": "crypto_btc",       "direction": "mixed", "confidence": 52, "reason": "Digital gold narrative — loose correlation"},
    ],
    "copper": [
        {"asset": "stock_spy",        "direction": "bull", "confidence": 68, "reason": "Copper as global growth indicator — Dr. Copper"},
        {"asset": "aud_usd",          "direction": "bull", "confidence": 75, "reason": "Australia major copper exporter"},
        {"asset": "chinese_equities", "direction": "bull", "confidence": 72, "reason": "China consumes 55% of world copper"},
        {"asset": "stock_fcx",        "direction": "bull", "confidence": 85, "reason": "Freeport-McMoRan — largest US copper producer"},
    ],
}

# ── Volume anomaly thresholds ────────────────────────────────────────────
VOLUME_THRESHOLDS = {
    "stock_spy":  {"multiplier": 2.5, "type": "equity"},
    "stock_qqq":  {"multiplier": 2.5, "type": "equity"},
    "stock_xle":  {"multiplier": 3.0, "type": "equity"},
    "crypto_btc": {"multiplier": 2.0, "type": "crypto"},
    "crypto_eth": {"multiplier": 2.0, "type": "crypto"},
    "wheat":      {"multiplier": 2.5, "type": "futures"},
    "gold":       {"multiplier": 2.0, "type": "futures"},
    "wti_crude":  {"multiplier": 2.0, "type": "futures"},
}


class MarketRadarEngine:
    """
    E8: Market Radar — real-time spike, volume, and chain reaction detection.
    """

    def __init__(self):
        self._price_history: dict[str, list[dict]] = {}  # asset_id -> [{price, ts}]
        self._volume_history: dict[str, list[float]] = {}  # asset_id -> [vol_30_days]
        self._active_alerts: list[dict] = []

    async def run_radar_scan(self) -> list[dict]:
        """
        Main scan — called every 5 minutes.
        Fetches current prices, checks for spikes and volume anomalies,
        triggers chain reactions for confirmed events.
        Returns list of new alerts generated this scan.
        """
        print("-> E8: Market Radar scan starting...")
        new_alerts = []

        # Fetch current prices
        prices = await self._fetch_all_prices()

        for asset_id, current_price in prices.items():
            if current_price <= 0:
                continue

            # Update price history
            self._update_price_history(asset_id, current_price)

            # Check for spike
            spike = self._check_spike(asset_id, current_price)
            if spike:
                alert = await self._create_spike_alert(asset_id, spike, current_price)
                if alert:
                    new_alerts.append(alert)
                    # Trigger chain reactions
                    chain_alerts = await self._trigger_chain_reactions(asset_id, spike)
                    new_alerts.extend(chain_alerts)

        # Check volume anomalies (separate from price)
        vol_anomalies = await self._check_volume_anomalies()
        new_alerts.extend(vol_anomalies)

        # Store alerts
        if new_alerts:
            await self._store_alerts(new_alerts)
            print(f"✓ E8: {len(new_alerts)} new alerts generated")
        else:
            print("✓ E8: No anomalies detected this scan")

        return new_alerts

    async def _fetch_all_prices(self) -> dict[str, float]:
        """Fetch current prices from all configured sources."""
        prices = {}
        tasks = [
            self._fetch_crypto_prices(),
            self._fetch_stock_prices(),
            self._fetch_commodity_prices(),
        ]
        results = await asyncio.gather(*tasks, return_exceptions=True)
        for result in results:
            if isinstance(result, dict):
                prices.update(result)
        return prices

    async def _fetch_crypto_prices(self) -> dict[str, float]:
        """Fetch crypto prices from CoinGecko."""
        prices = {}
        try:
            params = {
                "ids": "bitcoin,ethereum,solana",
                "vs_currencies": "usd"
            }
            if settings.coingecko_api_key:
                params["x_cg_demo_api_key"] = settings.coingecko_api_key

            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.get(
                    "https://api.coingecko.com/api/v3/simple/price",
                    params=params
                )
                resp.raise_for_status()
                data = resp.json()
                mapping = {
                    "bitcoin": "crypto_btc",
                    "ethereum": "crypto_eth",
                    "solana": "crypto_sol",
                }
                for coin_id, asset_id in mapping.items():
                    if coin_id in data:
                        prices[asset_id] = float(data[coin_id].get("usd", 0))
        except Exception as e:
            print(f"⚠ E8 crypto prices: {e}")
        return prices

    async def _fetch_stock_prices(self) -> dict[str, float]:
        """Fetch stock/ETF prices from yfinance."""
        prices = {}
        tickers = {
            "SPY": "stock_spy",
            "QQQ": "stock_qqq",
            "XLE": "stock_xle",
            "GLD": "gold",
            "USO": "stock_uso",
            "UNG": "natural_gas",
        }
        try:
            import yfinance as yf
            symbols = list(tickers.keys())
            data = yf.download(symbols, period="1d", interval="5m",
                               group_by="ticker", progress=False, auto_adjust=True)
            for ticker, asset_id in tickers.items():
                try:
                    if len(symbols) > 1:
                        close = data[ticker]["Close"].dropna()
                    else:
                        close = data["Close"].dropna()
                    if not close.empty:
                        prices[asset_id] = float(close.iloc[-1])
                except Exception:
                    pass
        except Exception as e:
            print(f"⚠ E8 stock prices: {e}")
        return prices

    async def _fetch_commodity_prices(self) -> dict[str, float]:
        """
        Fetch commodity futures prices.
        Free: yfinance (15min delayed)
        Paid: Alpha Vantage real-time (add ALPHA_VANTAGE_KEY to Replit Secrets)
        """
        prices = {}

        # Alpha Vantage (paid, real-time)
        if getattr(settings, "alpha_vantage_key", ""):
            prices.update(await self._fetch_alpha_vantage())
            return prices

        # Free fallback: yfinance futures tickers
        futures_tickers = {
            "CL=F": "wti_crude",
            "BZ=F": "brent_crude",
            "NG=F": "ttf_gas",
            "GC=F": "gold_futures",
            "SI=F": "silver",
            "HG=F": "copper",
            "ZW=F": "wheat",
            "ZC=F": "corn",
            "ZS=F": "soybeans",
        }
        try:
            import yfinance as yf
            for ticker, asset_id in futures_tickers.items():
                try:
                    t = yf.Ticker(ticker)
                    hist = t.history(period="1d", interval="5m")
                    if not hist.empty:
                        prices[asset_id] = float(hist["Close"].iloc[-1])
                except Exception:
                    pass
        except Exception as e:
            print(f"⚠ E8 commodity prices: {e}")
        return prices

    async def _fetch_alpha_vantage(self) -> dict[str, float]:
        """Fetch real-time commodity prices from Alpha Vantage (paid)."""
        prices = {}
        symbols = {
            "WTI": "wti_crude",
            "BRENT": "brent_crude",
            "NATURAL_GAS": "ttf_gas",
            "COPPER": "copper",
            "WHEAT": "wheat",
            "CORN": "corn",
        }
        key = getattr(settings, "alpha_vantage_key", "")
        async with httpx.AsyncClient(timeout=15) as client:
            for sym, asset_id in symbols.items():
                try:
                    resp = await client.get(
                        "https://www.alphavantage.co/query",
                        params={"function": "COMMODITY_" + sym if sym not in ("WTI", "BRENT")
                                else "COMMODITY_CRUDE_OIL_" + sym,
                                "apikey": key}
                    )
                    data = resp.json()
                    val = data.get("data", [{}])[0].get("value", "0")
                    prices[asset_id] = float(val) if val != "." else 0
                    await asyncio.sleep(0.5)  # Alpha Vantage rate limit
                except Exception:
                    pass
        return prices

    def _update_price_history(self, asset_id: str, price: float):
        """Maintain rolling 2-hour price history for spike detection."""
        now = datetime.utcnow()
        if asset_id not in self._price_history:
            self._price_history[asset_id] = []

        self._price_history[asset_id].append({
            "price": price,
            "ts": now,
        })

        # Keep only last 2 hours
        cutoff = now - timedelta(hours=2)
        self._price_history[asset_id] = [
            p for p in self._price_history[asset_id]
            if p["ts"] > cutoff
        ]

    def _check_spike(self, asset_id: str, current_price: float) -> Optional[dict]:
        """
        Check if price has moved beyond threshold within the window.
        Returns spike info dict or None.
        """
        config = SPIKE_THRESHOLDS.get(asset_id)
        if not config:
            return None

        history = self._price_history.get(asset_id, [])
        if len(history) < 2:
            return None

        window_mins = config["window"]
        cutoff = datetime.utcnow() - timedelta(minutes=window_mins)

        # Find price at start of window
        window_prices = [p for p in history if p["ts"] >= cutoff]
        if not window_prices:
            return None

        oldest_in_window = window_prices[0]["price"]
        if oldest_in_window == 0:
            return None

        pct_change = ((current_price - oldest_in_window) / oldest_in_window) * 100

        if abs(pct_change) >= config["pct"]:
            return {
                "pct_change": round(pct_change, 2),
                "direction": "up" if pct_change > 0 else "down",
                "window_minutes": window_mins,
                "threshold_pct": config["pct"],
                "severity": config["severity"],
                "price_at_start": oldest_in_window,
                "price_now": current_price,
            }
        return None

    async def _create_spike_alert(
        self, asset_id: str, spike: dict, current_price: float
    ) -> Optional[dict]:
        """Create a formatted alert for a price spike."""
        # Check dedup — don't alert same asset again within 30 minutes
        cache = get_cache()
        dedup_key = f"radar_alert:{asset_id}"
        if cache:
            try:
                if cache.get(dedup_key):
                    return None
                cache.set(dedup_key, "1", ex=1800)  # 30 min cooldown
            except Exception:
                pass

        direction_label = "up" if spike["direction"] == "up" else "down"
        asset_label = asset_id.replace("_", " ").replace("crypto ", "").replace("stock ", "").upper()

        # Look up chain reactions
        chains = [c["asset"] for c in CHAIN_REACTIONS.get(asset_id, [])]

        # Get historical context from E4 if available
        hist_note = await self._get_historical_context(asset_id, spike["pct_change"])

        alert = {
            "id": hashlib.md5(f"{asset_id}{datetime.utcnow().isoformat()}".encode()).hexdigest()[:10],
            "type": "price_spike",
            "severity": spike["severity"],
            "asset_id": asset_id,
            "asset_label": asset_label,
            "title": f"{asset_label} {direction_label} {abs(spike['pct_change']):.1f}% in {spike['window_minutes']} minutes",
            "pct_change": spike["pct_change"],
            "direction": spike["direction"],
            "price_start": spike["price_at_start"],
            "price_now": spike["price_now"],
            "window_minutes": spike["window_minutes"],
            "threshold_pct": spike["threshold_pct"],
            "chain_assets": chains[:6],
            "historical_note": hist_note,
            "ai_scanning": f"Scanning Reuters, AP, Bloomberg for {asset_label} catalyst...",
            "data_source": "yfinance / CoinGecko",
            "created_at": datetime.utcnow().isoformat(),
        }
        return alert

    async def _trigger_chain_reactions(self, trigger_asset: str, spike: dict) -> list[dict]:
        """When a spike is confirmed, flag downstream assets."""
        chain_alerts = []
        reactions = CHAIN_REACTIONS.get(trigger_asset, [])
        trigger_label = trigger_asset.replace("_", " ").upper()

        for reaction in reactions:
            if reaction["confidence"] < 60:
                continue  # Only high-confidence chains
            chain_alerts.append({
                "id": hashlib.md5(f"chain_{reaction['asset']}{datetime.utcnow().isoformat()}".encode()).hexdigest()[:10],
                "type": "chain_reaction",
                "severity": "medium",
                "asset_id": reaction["asset"],
                "asset_label": reaction["asset"].replace("_", " ").upper(),
                "title": f"Chain reaction: {trigger_label} spike → watch {reaction['asset'].replace('_',' ').upper()}",
                "direction": reaction["direction"],
                "confidence": reaction["confidence"],
                "reason": reaction["reason"],
                "trigger_asset": trigger_asset,
                "trigger_pct": spike["pct_change"],
                "chain_assets": [],
                "created_at": datetime.utcnow().isoformat(),
            })
        return chain_alerts

    async def _check_volume_anomalies(self) -> list[dict]:
        """
        Check for unusual trading volume.
        Free: yfinance volume comparison
        Paid: Unusual Whales API for options flow
        """
        anomalies = []

        # Check Unusual Whales if configured
        unusual_whales_key = getattr(settings, "unusual_whales_key", "")
        if unusual_whales_key:
            uw_anomalies = await self._fetch_unusual_whales(unusual_whales_key)
            anomalies.extend(uw_anomalies)

        # Free: yfinance volume check
        free_anomalies = await self._check_yfinance_volume()
        anomalies.extend(free_anomalies)

        return anomalies

    async def _fetch_unusual_whales(self, api_key: str) -> list[dict]:
        """Fetch options flow anomalies from Unusual Whales API (paid)."""
        anomalies = []
        try:
            async with httpx.AsyncClient(timeout=15) as client:
                resp = await client.get(
                    "https://api.unusualwhales.com/api/option-trades/flow-alerts",
                    headers={"Authorization": f"Bearer {api_key}"},
                    params={"limit": 20, "is_unusual": "true"}
                )
                resp.raise_for_status()
                data = resp.json().get("data", [])
                for item in data[:10]:
                    premium = float(item.get("premium", 0))
                    if premium < 1_000_000:  # Only flag $1M+ flows
                        continue
                    anomalies.append({
                        "id": hashlib.md5(str(item).encode()).hexdigest()[:10],
                        "type": "volume_anomaly",
                        "severity": "high" if premium > 10_000_000 else "medium",
                        "asset_id": item.get("ticker", "").lower(),
                        "asset_label": item.get("ticker", ""),
                        "title": f"Unusual options flow: ${premium/1_000_000:.1f}M in {item.get('ticker')} {item.get('strike')} {item.get('option_type', '').upper()}",
                        "volume_multiplier": None,
                        "volume_type": "options_flow",
                        "premium_usd": premium,
                        "strike": item.get("strike"),
                        "expiry": item.get("expiry_date"),
                        "option_type": item.get("option_type"),
                        "note": f"${premium/1_000_000:.1f}M premium — {'bullish' if item.get('option_type','').lower()=='call' else 'bearish'} signal",
                        "data_source": "Unusual Whales",
                        "chain_assets": CHAIN_REACTIONS.get(item.get("ticker", "").lower(), [])[:3],
                        "created_at": datetime.utcnow().isoformat(),
                    })
        except Exception as e:
            print(f"⚠ E8 Unusual Whales: {e}")
        return anomalies

    async def _check_yfinance_volume(self) -> list[dict]:
        """Check for volume spikes using free yfinance data."""
        anomalies = []
        tickers_to_check = {
            "SPY": ("stock_spy", "S&P 500 ETF"),
            "QQQ": ("stock_qqq", "NASDAQ 100 ETF"),
            "GLD": ("gold", "Gold ETF"),
            "USO": ("stock_uso", "Oil ETF"),
            "XLE": ("stock_xle", "Energy Sector ETF"),
        }
        try:
            import yfinance as yf
            for ticker, (asset_id, label) in tickers_to_check.items():
                try:
                    t = yf.Ticker(ticker)
                    hist = t.history(period="35d", interval="1d")
                    if len(hist) < 10:
                        continue

                    avg_volume = hist["Volume"].iloc[:-1].mean()
                    today_volume = hist["Volume"].iloc[-1]
                    multiplier = today_volume / avg_volume if avg_volume > 0 else 1

                    threshold = VOLUME_THRESHOLDS.get(asset_id, {}).get("multiplier", 3.0)
                    if multiplier >= threshold:
                        severity = "high" if multiplier >= threshold * 1.5 else "medium"
                        anomalies.append({
                            "id": hashlib.md5(f"vol_{asset_id}{datetime.utcnow().date()}".encode()).hexdigest()[:10],
                            "type": "volume_anomaly",
                            "severity": severity,
                            "asset_id": asset_id,
                            "asset_label": label,
                            "title": f"{label} volume {multiplier:.1f}x 30-day average",
                            "volume_multiplier": round(multiplier, 1),
                            "volume_type": "equity_volume",
                            "note": (f"Volume {multiplier:.1f}x above average. "
                                     f"Elevated volume often precedes significant price moves within 1–3 days."),
                            "data_source": "yfinance",
                            "chain_assets": [c["asset"] for c in CHAIN_REACTIONS.get(asset_id, [])[:3]],
                            "created_at": datetime.utcnow().isoformat(),
                        })
                except Exception:
                    pass
        except Exception as e:
            print(f"⚠ E8 yfinance volume: {e}")
        return anomalies

    async def _get_historical_context(self, asset_id: str, pct_change: float) -> str:
        """Pull historical pattern note from E4 correlation records."""
        try:
            db = get_db()
            result = db.table("correlation_records") \
                .select("pattern_note") \
                .eq("asset_id", asset_id) \
                .order("created_at", desc=True) \
                .limit(1).execute()
            if result.data:
                return result.data[0].get("pattern_note", "")
        except Exception:
            pass

        # Fallback hardcoded patterns
        patterns = {
            "brent_crude": "Moves of this magnitude without news have preceded breaking geopolitical events within 60 min in 6 of 10 historical cases (2011, 2014, 2019, 2022).",
            "crypto_btc": "Bitcoin moves >3% in 15 min often signal either major exchange news or macro catalyst. Check CME futures premium and exchange reserve data.",
            "wheat": "Wheat spikes of this size typically follow crop reports, Black Sea shipping events, or major producer export bans. Check USDA calendar.",
            "gold": "Gold spikes above 1.5% in 30 min often precede or follow major Fed statements, geopolitical events, or USD selloffs. Check DXY simultaneously.",
            "stock_spy": "SPY 1%+ intraday spikes most commonly follow surprise Fed communications, major economic data, or geopolitical shocks.",
        }
        return patterns.get(asset_id, "Monitoring for catalyst — no historical pattern data available for this asset yet.")

    async def _store_alerts(self, alerts: list[dict]):
        """Store alerts in Supabase for retrieval by the frontend."""
        try:
            db = get_db()
            for alert in alerts:
                db.table("radar_alerts").upsert(alert, on_conflict="id").execute()
        except Exception as e:
            print(f"⚠ E8 store_alerts: {e}")

    async def get_active_alerts(self, hours: int = 4, alert_type: str = None) -> list[dict]:
        """Return recent alerts from the database."""
        try:
            db = get_db()
            cutoff = (datetime.utcnow() - timedelta(hours=hours)).isoformat()
            query = db.table("radar_alerts") \
                .select("*") \
                .gte("created_at", cutoff) \
                .order("created_at", desc=True) \
                .limit(50)
            if alert_type:
                query = query.eq("type", alert_type)
            return query.execute().data
        except Exception as e:
            print(f"⚠ E8 get_active_alerts: {e}")
            return []

    async def get_price_monitor(self) -> list[dict]:
        """Return current price snapshot with spike status."""
        prices = await self._fetch_all_prices()
        results = []
        for asset_id, price in prices.items():
            spike = self._check_spike(asset_id, price) if asset_id in SPIKE_THRESHOLDS else None
            config = SPIKE_THRESHOLDS.get(asset_id, {})
            results.append({
                "asset_id": asset_id,
                "asset_label": asset_id.replace("_", " ").replace("crypto ", "").replace("stock ", "").upper(),
                "price": price,
                "spike_detected": spike is not None,
                "pct_change": spike["pct_change"] if spike else None,
                "severity": spike["severity"] if spike else "normal",
                "threshold": f"{config.get('pct', 0)}% / {config.get('window', 0)}min",
                "updated_at": datetime.utcnow().isoformat(),
            })
        results.sort(key=lambda x: abs(x.get("pct_change") or 0), reverse=True)
        return results


# Singleton
radar_engine = MarketRadarEngine()


async def run_radar_scan():
    """Entry point for APScheduler job."""
    return await radar_engine.run_radar_scan()
PYEOF

echo "[2/7] Creating Radar API router..."

cat > backend/api/radar.py << 'PYEOF'
"""Market Radar API — real-time alerts, volume anomalies, chain reactions."""
from fastapi import APIRouter, Query
from typing import Optional
from datetime import datetime, timedelta
from backend.engines.market_radar import radar_engine, run_radar_scan, CHAIN_REACTIONS, SPIKE_THRESHOLDS
from backend.db.database import get_db
from fastapi import BackgroundTasks

router = APIRouter()


@router.get("/alerts")
async def get_alerts(
    hours: int = Query(4, description="Hours of history to return"),
    alert_type: Optional[str] = Query(None, description="price_spike | volume_anomaly | chain_reaction | news_catalyst"),
    severity: Optional[str] = Query(None, description="critical | high | medium"),
):
    """Return recent market alerts from the radar engine."""
    alerts = await radar_engine.get_active_alerts(hours=hours, alert_type=alert_type)
    if severity:
        alerts = [a for a in alerts if a.get("severity") == severity]
    return {
        "alerts": alerts,
        "total": len(alerts),
        "generated_at": datetime.utcnow().isoformat(),
    }


@router.get("/prices")
async def get_price_monitor():
    """Return current prices with spike status for all monitored assets."""
    prices = await radar_engine.get_price_monitor()
    return {
        "prices": prices,
        "total": len(prices),
        "updated_at": datetime.utcnow().isoformat(),
    }


@router.post("/scan")
async def trigger_scan(background_tasks: BackgroundTasks):
    """Manually trigger a radar scan."""
    background_tasks.add_task(run_radar_scan)
    return {
        "status": "scan_started",
        "message": "Radar scan running in background. Check /api/radar/alerts in ~30 seconds.",
    }


@router.get("/chains/{asset_id}")
async def get_chain_reactions(asset_id: str):
    """Return the chain reaction map for a specific asset."""
    chains = CHAIN_REACTIONS.get(asset_id, [])
    return {
        "asset_id": asset_id,
        "chains": chains,
        "total": len(chains),
        "note": f"When {asset_id.replace('_',' ').upper()} moves significantly, these assets are typically affected.",
    }


@router.get("/chains")
async def get_all_chains():
    """Return the full cross-asset chain reaction map."""
    return {
        "chains": CHAIN_REACTIONS,
        "total_assets": len(CHAIN_REACTIONS),
        "note": "Full cross-asset correlation map. Each key is a trigger asset; value is list of downstream effects.",
    }


@router.get("/thresholds")
async def get_thresholds():
    """Return spike detection thresholds for all monitored assets."""
    return {
        "thresholds": SPIKE_THRESHOLDS,
        "total": len(SPIKE_THRESHOLDS),
        "note": "Configure spike sensitivity. pct = percentage move, window = minutes to detect it in.",
    }


@router.get("/history")
async def get_alert_history(days: int = 7, limit: int = 100):
    """Return historical alerts for trend analysis."""
    try:
        db = get_db()
        cutoff = (datetime.utcnow() - timedelta(days=days)).isoformat()
        result = db.table("radar_alerts") \
            .select("*") \
            .gte("created_at", cutoff) \
            .order("created_at", desc=True) \
            .limit(limit).execute()
        alerts = result.data

        # Summary stats
        by_type = {}
        by_severity = {}
        for a in alerts:
            t = a.get("type", "unknown")
            s = a.get("severity", "unknown")
            by_type[t] = by_type.get(t, 0) + 1
            by_severity[s] = by_severity.get(s, 0) + 1

        return {
            "alerts": alerts,
            "total": len(alerts),
            "by_type": by_type,
            "by_severity": by_severity,
            "period_days": days,
        }
    except Exception as e:
        return {"alerts": [], "error": str(e)}


@router.get("/status")
async def get_radar_status():
    """Return radar engine status and data source availability."""
    from backend.config import settings
    sources = {
        "coingecko": {
            "status": "active",
            "tier": "free",
            "note": "Crypto prices every 30s"
        },
        "yfinance": {
            "status": "active",
            "tier": "free",
            "note": "Stocks/ETFs/commodities — 15min delayed"
        },
        "alpaca_websocket": {
            "status": "active" if getattr(settings, "alpaca_api_key", "") else "not_configured",
            "tier": "free",
            "note": "Real-time US stock prices — add ALPACA_API_KEY"
        },
        "unusual_whales": {
            "status": "active" if getattr(settings, "unusual_whales_key", "") else "not_configured",
            "tier": "paid (~$50-200/mo)",
            "note": "Options flow anomalies — add UNUSUAL_WHALES_KEY to Replit Secrets"
        },
        "alpha_vantage": {
            "status": "active" if getattr(settings, "alpha_vantage_key", "") else "not_configured",
            "tier": "paid (~$50/mo)",
            "note": "Real-time commodity prices — add ALPHA_VANTAGE_KEY to Replit Secrets"
        },
        "finnhub": {
            "status": "active" if getattr(settings, "finnhub_key", "") else "not_configured",
            "tier": "freemium",
            "note": "News catalyst detection — add FINNHUB_KEY to Replit Secrets"
        },
    }
    active = sum(1 for s in sources.values() if s["status"] == "active")
    return {
        "engine": "E8 Market Radar",
        "scan_frequency": "Every 5 minutes",
        "assets_monitored": len(SPIKE_THRESHOLDS),
        "chain_maps": len(CHAIN_REACTIONS),
        "sources": sources,
        "active_sources": active,
        "total_sources": len(sources),
    }
PYEOF

echo "[3/7] Updating jobs.py with radar scan job..."

cat > backend/tasks/jobs.py << 'PYEOF'
"""Background jobs via APScheduler."""
from backend.engines.ingestion import ingest_all_markets
from backend.engines.research import research_asset
from backend.engines.probability import score_asset
from backend.engines.recommendations import scan_for_recommendations
from backend.engines.market_radar import run_radar_scan
from backend.db.database import get_db
import asyncio


async def fetch_all_markets():
    print("-> Job: fetch_all_markets")
    try:
        assets = await ingest_all_markets()
        print(f"✓ Job: fetched {len(assets)} assets")
    except Exception as e:
        print(f"⚠ Job fetch_all_markets: {e}")


async def run_research_agent():
    print("-> Job: run_research_agent")
    try:
        db = get_db()
        from datetime import datetime, timedelta
        cutoff = (datetime.utcnow() - timedelta(hours=1)).isoformat()
        res = db.table("assets").select("*") \
            .lt("last_scored_at", cutoff) \
            .order("market_price", desc=True) \
            .limit(10).execute()
        from backend.models.asset import Asset
        for asset_data in res.data:
            asset = Asset(**asset_data)
            evidence = await research_asset(asset)
            await score_asset(asset, evidence)
            await asyncio.sleep(2)
        print(f"✓ Job: scored {len(res.data)} assets")
    except Exception as e:
        print(f"⚠ Job run_research_agent: {e}")


async def run_recommendations_scan():
    print("-> Job: run_recommendations_scan")
    try:
        briefing = await scan_for_recommendations()
        print(f"✓ Job: {briefing.trade_count} trades, {briefing.watch_count} watches, scan #{briefing.scan_number}")
    except Exception as e:
        print(f"⚠ Job run_recommendations_scan: {e}")


async def run_market_radar():
    """E8: Market Radar — price spikes, volume anomalies, chain reactions."""
    print("-> Job: run_market_radar")
    try:
        alerts = await run_radar_scan()
        print(f"✓ Job: radar scan complete — {len(alerts)} alerts generated")
    except Exception as e:
        print(f"⚠ Job run_market_radar: {e}")
PYEOF

echo "[4/7] Updating main.py with radar router and 5-min job..."

cat > backend/main.py << 'PYEOF'
from fastapi import FastAPI, WebSocket, WebSocketDisconnect
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from apscheduler.schedulers.asyncio import AsyncIOScheduler
import asyncio, json, os

from backend.api import markets, signals, portfolio, coach
from backend.api.recommendations import router as rec_router
from backend.api.live_trading import router as trading_router
from backend.api.radar import router as radar_router
from backend.tasks.jobs import (
    fetch_all_markets, run_research_agent,
    run_recommendations_scan, run_market_radar
)
from backend.db.database import init_db

app = FastAPI(title="Alpha Lens API", version="3.0.0",
              description="AI-Powered Global Investment Intelligence Platform")

app.add_middleware(CORSMiddleware, allow_origins=["*"],
                   allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

app.include_router(markets.router,  prefix="/api/markets",         tags=["markets"])
app.include_router(signals.router,  prefix="/api/signals",         tags=["signals"])
app.include_router(portfolio.router,prefix="/api/portfolio",        tags=["portfolio"])
app.include_router(coach.router,    prefix="/api/coach",            tags=["coach"])
app.include_router(rec_router,      prefix="/api/recommendations",  tags=["recommendations"])
app.include_router(trading_router,  prefix="/api/trading",          tags=["trading"])
app.include_router(radar_router,    prefix="/api/radar",            tags=["radar"])


class ConnectionManager:
    def __init__(self): self.connections = {}
    async def connect(self, ws, asset_id):
        await ws.accept()
        if asset_id not in self.connections: self.connections[asset_id] = []
        self.connections[asset_id].append(ws)
    def disconnect(self, ws, asset_id):
        if asset_id in self.connections:
            self.connections[asset_id].remove(ws)
    async def broadcast(self, asset_id, data):
        for ws in self.connections.get(asset_id, []):
            try: await ws.send_text(json.dumps(data))
            except: pass

manager = ConnectionManager()


@app.websocket("/ws/signals/{asset_id}")
async def signal_ws(ws: WebSocket, asset_id: str):
    await manager.connect(ws, asset_id)
    try:
        while True:
            await asyncio.sleep(30)
            await ws.send_text(json.dumps({"type": "ping"}))
    except WebSocketDisconnect:
        manager.disconnect(ws, asset_id)


@app.websocket("/ws/radar")
async def radar_ws(ws: WebSocket):
    """WebSocket for live radar alerts pushed to frontend."""
    await ws.accept()
    try:
        while True:
            await asyncio.sleep(30)
            await ws.send_text(json.dumps({"type": "ping"}))
    except WebSocketDisconnect:
        pass


scheduler = AsyncIOScheduler()


@app.on_event("startup")
async def startup():
    await init_db()
    scheduler.add_job(fetch_all_markets,       "interval", minutes=15,  id="fetch_markets",        replace_existing=True)
    scheduler.add_job(run_research_agent,       "interval", hours=1,     id="research_agent",       replace_existing=True)
    scheduler.add_job(run_recommendations_scan, "interval", minutes=30,  id="recommendations_scan", replace_existing=True)
    scheduler.add_job(run_market_radar,         "interval", minutes=5,   id="market_radar",         replace_existing=True)
    scheduler.start()
    print("✓ Alpha Lens v3.0 started — 4 background jobs active")
    print("  markets(15min) · research(60min) · recommendations(30min) · radar(5min)")


@app.on_event("shutdown")
async def shutdown():
    scheduler.shutdown()


@app.get("/api/health")
async def health():
    return {
        "status": "ok", "version": "3.0.0",
        "jobs": ["fetch_markets", "research_agent", "recommendations_scan", "market_radar"]
    }


frontend_path = "frontend/out"
if os.path.exists(frontend_path):
    app.mount("/", StaticFiles(directory=frontend_path, html=True))
else:
    @app.get("/")
    async def root():
        return {"message": "Alpha Lens API — build frontend: cd frontend && npm install && npm run build"}
PYEOF

echo "[5/7] Adding optional secrets to config.py..."

cat > backend/config.py << 'PYEOF'
from pydantic_settings import BaseSettings
from functools import lru_cache

class Settings(BaseSettings):
    anthropic_api_key: str = ""
    supabase_url: str = ""
    supabase_anon_key: str = ""
    supabase_service_key: str = ""
    database_url: str = ""
    upstash_redis_url: str = ""
    upstash_redis_token: str = ""
    polymarket_api_key: str = ""
    polymarket_secret: str = ""
    polymarket_passphrase: str = ""
    polymarket_private_key: str = ""
    polygon_wallet_address: str = ""
    kalshi_email: str = ""
    kalshi_password: str = ""
    alpaca_api_key: str = ""
    alpaca_secret_key: str = ""
    alpaca_base_url: str = "https://paper-api.alpaca.markets"
    coinbase_api_key: str = ""
    coinbase_api_secret: str = ""
    kraken_api_key: str = ""
    kraken_private_key: str = ""
    coingecko_api_key: str = ""
    newsapi_key: str = ""
    # E8 Market Radar — optional paid sources
    unusual_whales_key: str = ""      # unusualwhales.com — options flow $50-200/mo
    alpha_vantage_key: str = ""       # alphavantage.co — real-time commodities $50/mo
    finnhub_key: str = ""             # finnhub.io — news catalyst free tier available
    # Risk controls
    execution_mode: str = "manual"
    require_approval: str = "true"
    min_edge_to_execute: str = "5"
    min_confidence: str = "65"
    min_evidence_count: str = "3"
    max_position_pct: str = "0.05"
    max_daily_trades: str = "10"
    max_correlated_positions: str = "3"
    max_spread_pct: str = "0.08"
    daily_loss_limit_pct: str = "0.10"
    us_jurisdiction_mode: str = "true"
    app_env: str = "development"
    paper_balance_default: float = 10000.0

    class Config:
        env_file = ".env"
        extra = "ignore"

@lru_cache()
def get_settings() -> Settings:
    return Settings()

settings = get_settings()
PYEOF

echo "[6/7] Creating Supabase radar tables SQL..."

cat > scripts/add_radar_tables.sql << 'SQLEOF'
-- Run in Supabase SQL Editor
-- Adds Market Radar (E8) tables

CREATE TABLE IF NOT EXISTS radar_alerts (
    id TEXT PRIMARY KEY,
    type TEXT NOT NULL,                     -- price_spike | volume_anomaly | chain_reaction | news_catalyst
    severity TEXT DEFAULT 'medium',         -- critical | high | medium | low
    asset_id TEXT DEFAULT '',
    asset_label TEXT DEFAULT '',
    title TEXT NOT NULL,
    pct_change DOUBLE PRECISION,
    direction TEXT DEFAULT '',              -- up | down | bull | bear
    price_start DOUBLE PRECISION,
    price_now DOUBLE PRECISION,
    window_minutes INTEGER,
    threshold_pct DOUBLE PRECISION,
    volume_multiplier DOUBLE PRECISION,
    volume_type TEXT DEFAULT '',
    confidence INTEGER,
    reason TEXT DEFAULT '',
    trigger_asset TEXT DEFAULT '',
    trigger_pct DOUBLE PRECISION,
    chain_assets JSONB DEFAULT '[]',
    historical_note TEXT DEFAULT '',
    ai_scanning TEXT DEFAULT '',
    note TEXT DEFAULT '',
    data_source TEXT DEFAULT '',
    created_at TIMESTAMPTZ DEFAULT NOW()
);

-- Index for fast recent alert queries
CREATE INDEX IF NOT EXISTS idx_radar_alerts_created
ON radar_alerts(created_at DESC);

CREATE INDEX IF NOT EXISTS idx_radar_alerts_type
ON radar_alerts(type, created_at DESC);

CREATE INDEX IF NOT EXISTS idx_radar_alerts_severity
ON radar_alerts(severity, created_at DESC);
SQLEOF

echo "[7/7] Creating frontend Radar page..."

mkdir -p frontend/pages

cat > frontend/pages/radar.tsx << 'TSXEOF'
import { useState, useEffect, useCallback } from 'react'
import Layout from '../components/Layout'

const BASE = process.env.NEXT_PUBLIC_API_URL || ''

interface Alert {
  id: string
  type: string
  severity: string
  asset_label: string
  title: string
  pct_change?: number
  direction?: string
  chain_assets?: string[]
  historical_note?: string
  ai_scanning?: string
  note?: string
  volume_multiplier?: number
  confidence?: number
  reason?: string
  trigger_asset?: string
  data_source?: string
  created_at: string
}

interface PriceRow {
  asset_id: string
  asset_label: string
  price: number
  spike_detected: boolean
  pct_change?: number
  severity: string
  threshold: string
  updated_at: string
}

const SEV_STYLE: Record<string, { card: string; badge: string; border: string }> = {
  critical: { card: 'bg-red-50',    badge: 'bg-red-100 text-red-800',    border: 'border-l-red-500' },
  high:     { card: 'bg-amber-50',  badge: 'bg-amber-100 text-amber-800', border: 'border-l-amber-500' },
  medium:   { card: 'bg-blue-50',   badge: 'bg-blue-100 text-blue-700',   border: 'border-l-blue-400' },
  low:      { card: 'bg-gray-50',   badge: 'bg-gray-100 text-gray-600',   border: 'border-l-gray-300' },
  normal:   { card: 'bg-gray-50',   badge: 'bg-gray-100 text-gray-600',   border: 'border-l-gray-200' },
}

const TYPE_LABEL: Record<string, string> = {
  price_spike:    'Price spike',
  volume_anomaly: 'Volume anomaly',
  chain_reaction: 'Chain reaction',
  news_catalyst:  'News catalyst',
}

export default function RadarPage() {
  const [alerts, setAlerts] = useState<Alert[]>([])
  const [prices, setPrices] = useState<PriceRow[]>([])
  const [status, setStatus] = useState<any>(null)
  const [loading, setLoading] = useState(true)
  const [scanning, setScanning] = useState(false)
  const [tab, setTab] = useState<'alerts' | 'prices' | 'sources'>('alerts')
  const [sevFilter, setSevFilter] = useState('all')
  const [typeFilter, setTypeFilter] = useState('all')
  const [lastUpdated, setLastUpdated] = useState('')

  const load = useCallback(async () => {
    try {
      const [aRes, pRes, sRes] = await Promise.all([
        fetch(`${BASE}/api/radar/alerts?hours=8`),
        fetch(`${BASE}/api/radar/prices`),
        fetch(`${BASE}/api/radar/status`),
      ])
      const [aData, pData, sData] = await Promise.all([aRes.json(), pRes.json(), sRes.json()])
      setAlerts(aData.alerts || [])
      setPrices(pData.prices || [])
      setStatus(sData)
      setLastUpdated(new Date().toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit', second: '2-digit' }))
    } catch (e) { console.error(e) }
    finally { setLoading(false) }
  }, [])

  useEffect(() => {
    load()
    const iv = setInterval(load, 5 * 60 * 1000) // refresh every 5 min
    return () => clearInterval(iv)
  }, [load])

  async function triggerScan() {
    setScanning(true)
    try {
      await fetch(`${BASE}/api/radar/scan`, { method: 'POST' })
      setTimeout(async () => { await load(); setScanning(false) }, 35000)
    } catch { setScanning(false) }
  }

  const filteredAlerts = alerts.filter(a => {
    if (sevFilter !== 'all' && a.severity !== sevFilter) return false
    if (typeFilter !== 'all' && a.type !== typeFilter) return false
    return true
  })

  const spikeCount = alerts.filter(a => a.type === 'price_spike').length
  const volCount = alerts.filter(a => a.type === 'volume_anomaly').length
  const chainCount = alerts.filter(a => a.type === 'chain_reaction').length
  const criticalCount = alerts.filter(a => a.severity === 'critical' || a.severity === 'high').length

  return (
    <Layout>
      <div className="flex items-center gap-3 mb-5 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-navy">Market Radar</h1>
          <p className="text-sm text-gray-500 mt-0.5">
            Real-time price spikes · Volume anomalies · Cross-asset chain reactions · Updated {lastUpdated || '—'}
          </p>
        </div>
        <div className="flex items-center gap-1.5 ml-2">
          <span className="live-dot" />
          <span className="text-xs text-gray-500">Live — scans every 5 min</span>
        </div>
        <div className="flex-1" />
        <button onClick={triggerScan} disabled={scanning}
          className="text-sm bg-navy text-white px-4 py-2 rounded-lg hover:opacity-90 disabled:opacity-60">
          {scanning ? 'Scanning (~30s)...' : 'Scan now'}
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-4 gap-3 mb-5">
        {[
          { label: 'Critical / High alerts', val: criticalCount, color: criticalCount > 0 ? 'text-red-700' : 'text-navy' },
          { label: 'Price spikes', val: spikeCount, color: 'text-navy' },
          { label: 'Volume anomalies', val: volCount, color: 'text-amber-700' },
          { label: 'Chain reactions', val: chainCount, color: 'text-blue-700' },
        ].map(s => (
          <div key={s.label} className="bg-gray-50 rounded-xl p-3">
            <div className="text-xs text-gray-500 mb-1">{s.label}</div>
            <div className={`text-2xl font-bold ${s.color}`}>{s.val}</div>
          </div>
        ))}
      </div>

      {/* Tabs */}
      <div className="flex gap-1 border-b border-gray-200 mb-5">
        {([['alerts','Live alerts'],['prices','Price monitor'],['sources','Data sources']] as const).map(([id, label]) => (
          <button key={id} onClick={() => setTab(id)}
            className={`px-4 py-2.5 text-sm border-b-2 transition-colors ${tab===id ? 'border-navy text-navy font-medium' : 'border-transparent text-gray-500 hover:text-gray-700'}`}>
            {label}
          </button>
        ))}
      </div>

      {/* ALERTS TAB */}
      {tab === 'alerts' && (
        <>
          <div className="flex items-center gap-3 mb-4 flex-wrap">
            <select value={sevFilter} onChange={e => setSevFilter(e.target.value)}
              className="text-xs border border-gray-300 rounded px-2 py-1.5">
              <option value="all">All severities</option>
              <option value="critical">Critical</option>
              <option value="high">High</option>
              <option value="medium">Medium</option>
            </select>
            <select value={typeFilter} onChange={e => setTypeFilter(e.target.value)}
              className="text-xs border border-gray-300 rounded px-2 py-1.5">
              <option value="all">All types</option>
              <option value="price_spike">Price spikes</option>
              <option value="volume_anomaly">Volume anomalies</option>
              <option value="chain_reaction">Chain reactions</option>
            </select>
          </div>

          {loading ? (
            <div className="text-center py-20 text-gray-400">
              <div className="animate-pulse text-lg mb-2">Scanning markets...</div>
              <p className="text-sm">First scan may take up to 30 seconds</p>
            </div>
          ) : filteredAlerts.length === 0 ? (
            <div className="text-center py-20 text-gray-400">
              <div className="text-lg mb-2">No alerts in the last 8 hours</div>
              <p className="text-sm mb-4">Markets are moving within normal thresholds. Click Scan now to check immediately.</p>
              <button onClick={triggerScan} disabled={scanning}
                className="text-sm bg-navy text-white px-4 py-2 rounded-lg hover:opacity-90 disabled:opacity-60">
                {scanning ? 'Scanning...' : 'Scan now'}
              </button>
            </div>
          ) : (
            filteredAlerts.map(alert => {
              const style = SEV_STYLE[alert.severity] || SEV_STYLE.medium
              const isUp = (alert.pct_change || 0) > 0 || alert.direction === 'up' || alert.direction === 'bull'
              return (
                <div key={alert.id} className={`${style.card} border-l-4 ${style.border} rounded-r-xl p-4 mb-3`}>
                  <div className="flex items-center gap-2 mb-2 flex-wrap">
                    <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${style.badge}`}>
                      {alert.severity.toUpperCase()}
                    </span>
                    <span className="text-xs bg-gray-100 text-gray-600 px-2 py-0.5 rounded">
                      {TYPE_LABEL[alert.type] || alert.type}
                    </span>
                    <span className="text-sm font-semibold text-navy">{alert.asset_label}</span>
                    <span className="flex-1" />
                    {alert.pct_change != null && (
                      <span className={`text-sm font-bold ${isUp ? 'text-green-700' : 'text-red-700'}`}>
                        {isUp ? '+' : ''}{alert.pct_change.toFixed(1)}%
                      </span>
                    )}
                    {alert.confidence && (
                      <span className="text-xs text-gray-500">{alert.confidence}% confident</span>
                    )}
                    <span className="text-xs text-gray-400">
                      {new Date(alert.created_at).toLocaleTimeString('en-US', { hour: '2-digit', minute: '2-digit' })}
                    </span>
                  </div>

                  <p className="text-sm font-medium text-navy mb-1">{alert.title}</p>
                  {(alert.note || alert.reason || alert.historical_note) && (
                    <p className="text-xs text-gray-600 leading-relaxed mb-2">
                      {alert.note || alert.reason || alert.historical_note}
                    </p>
                  )}

                  {alert.chain_assets && alert.chain_assets.length > 0 && (
                    <div className="flex items-center gap-2 flex-wrap mb-2">
                      <span className="text-xs text-gray-500 font-medium">Watch:</span>
                      {alert.chain_assets.map(a => (
                        <span key={a} className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded">{a.replace(/_/g,' ').toUpperCase()}</span>
                      ))}
                    </div>
                  )}

                  {alert.ai_scanning && (
                    <div className="text-xs bg-white/60 rounded px-2 py-1 text-gray-600 italic">
                      {alert.ai_scanning}
                    </div>
                  )}
                  {alert.data_source && (
                    <span className="text-xs text-gray-400 mt-1 inline-block">Source: {alert.data_source}</span>
                  )}
                </div>
              )
            })
          )}
        </>
      )}

      {/* PRICES TAB */}
      {tab === 'prices' && (
        <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
          <div className="grid grid-cols-[2fr_1fr_1fr_1fr_1fr] gap-3 px-4 py-2.5 bg-gray-50 border-b border-gray-200 text-xs text-gray-500 font-medium">
            <div>Asset</div>
            <div className="text-right">Price</div>
            <div className="text-right">Change</div>
            <div className="text-center">Status</div>
            <div className="text-right">Threshold</div>
          </div>
          {prices.length === 0 ? (
            <div className="text-center py-10 text-gray-400 text-sm">
              No price data yet. Click Scan now to fetch prices.
            </div>
          ) : (
            prices.map(p => (
              <div key={p.asset_id} className="grid grid-cols-[2fr_1fr_1fr_1fr_1fr] gap-3 px-4 py-3 border-b border-gray-100 last:border-0 items-center">
                <div className="text-sm font-medium text-navy">{p.asset_label}</div>
                <div className="text-sm text-right font-medium">
                  {p.price > 1000 ? `$${p.price.toLocaleString('en-US', {maximumFractionDigits:0})}`
                   : p.price > 1 ? `$${p.price.toFixed(2)}`
                   : `$${p.price.toFixed(4)}`}
                </div>
                <div className={`text-sm text-right font-medium ${(p.pct_change || 0) >= 0 ? 'text-green-700' : 'text-red-700'}`}>
                  {p.pct_change != null ? `${p.pct_change > 0 ? '+' : ''}${p.pct_change.toFixed(1)}%` : '—'}
                </div>
                <div className="text-center">
                  {p.spike_detected
                    ? <span className="text-xs font-semibold bg-red-100 text-red-800 px-2 py-0.5 rounded-full">SPIKE</span>
                    : <span className="text-xs text-gray-400">Normal</span>}
                </div>
                <div className="text-xs text-gray-400 text-right">{p.threshold}</div>
              </div>
            ))
          )}
        </div>
      )}

      {/* SOURCES TAB */}
      {tab === 'sources' && status && (
        <>
          <div className="grid grid-cols-3 gap-3 mb-5">
            <div className="bg-gray-50 rounded-xl p-3">
              <div className="text-xs text-gray-500 mb-1">Active sources</div>
              <div className="text-2xl font-bold text-green-700">{status.active_sources}</div>
            </div>
            <div className="bg-gray-50 rounded-xl p-3">
              <div className="text-xs text-gray-500 mb-1">Assets monitored</div>
              <div className="text-2xl font-bold text-navy">{status.assets_monitored}</div>
            </div>
            <div className="bg-gray-50 rounded-xl p-3">
              <div className="text-xs text-gray-500 mb-1">Chain reaction maps</div>
              <div className="text-2xl font-bold text-navy">{status.chain_maps}</div>
            </div>
          </div>

          <div className="bg-amber-50 border border-amber-200 rounded-xl p-4 mb-4 text-sm text-amber-800">
            <strong>Upgrade options:</strong> For real-time commodity prices (vs 15-min delay), add <code>ALPHA_VANTAGE_KEY</code> (~$50/mo).
            For options flow / dark pool large volume, add <code>UNUSUAL_WHALES_KEY</code> (~$50-200/mo).
            Both keys go in Replit Secrets.
          </div>

          <div className="bg-white border border-gray-200 rounded-xl overflow-hidden">
            <div className="grid grid-cols-[2fr_1fr_1fr_1fr_auto] gap-3 px-4 py-2.5 bg-gray-50 border-b text-xs text-gray-500 font-medium">
              <div>Source</div><div>Frequency</div><div>Assets</div><div>Cost</div><div>Status</div>
            </div>
            {Object.entries(status.sources || {}).map(([name, s]: [string, any]) => (
              <div key={name} className="grid grid-cols-[2fr_1fr_1fr_1fr_auto] gap-3 px-4 py-3 border-b border-gray-100 last:border-0 items-center">
                <div>
                  <div className="text-sm font-medium text-navy">{name.replace(/_/g,' ')}</div>
                  <div className="text-xs text-gray-400">{s.note}</div>
                </div>
                <div className="text-xs text-gray-600">{s.freq || '—'}</div>
                <div className="text-xs text-gray-600">{s.assets || '—'}</div>
                <div className="text-xs text-gray-600">{s.tier || s.cost || '—'}</div>
                <div>
                  {s.status === 'active'
                    ? <span className="text-xs bg-green-100 text-green-800 px-2 py-0.5 rounded-full font-medium">Active</span>
                    : <span className="text-xs bg-amber-100 text-amber-800 px-2 py-0.5 rounded-full font-medium">Add key</span>}
                </div>
              </div>
            ))}
          </div>
        </>
      )}
    </Layout>
  )
}
TSXEOF

# Update Layout to include Radar link
cat > frontend/components/Layout.tsx << 'TSXEOF'
import Link from 'next/link'
import { useRouter } from 'next/router'
import clsx from 'clsx'

const NAV = [
  { href: '/',         label: 'Scanner'    },
  { href: '/briefing', label: 'Briefing'   },
  { href: '/radar',    label: 'Radar'      },
  { href: '/coach',    label: 'Coach'      },
  { href: '/portfolio',label: 'Portfolio'  },
  { href: '/learn',    label: 'Learn'      },
]

export default function Layout({ children }: { children: React.ReactNode }) {
  const router = useRouter()
  return (
    <div className="min-h-screen flex flex-col">
      <header className="bg-white border-b border-gray-200 sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 flex items-center gap-2 h-14">
          <Link href="/" className="font-bold text-lg text-navy tracking-tight mr-2">Alpha Lens</Link>
          <span className="text-xs bg-blue-100 text-blue-700 px-2 py-0.5 rounded-full font-medium">v3.0</span>
          <nav className="flex items-center gap-1 flex-1">
            {NAV.map(({ href, label }) => (
              <Link key={href} href={href} className={clsx(
                'px-3 py-1.5 rounded text-sm transition-colors',
                router.pathname === href
                  ? 'bg-navy text-white font-medium'
                  : href === '/briefing'
                    ? 'text-accent font-medium hover:bg-blue-50 border border-accent/30'
                    : href === '/radar'
                      ? 'text-red-700 font-medium hover:bg-red-50 border border-red-200'
                      : 'text-gray-600 hover:bg-gray-100'
              )}>{label}</Link>
            ))}
          </nav>
          <div className="flex items-center gap-2 ml-2">
            <span className="live-dot" />
            <span className="text-xs text-gray-500">Live</span>
          </div>
        </div>
      </header>
      <main className="flex-1 max-w-7xl mx-auto w-full px-4 py-6">{children}</main>
      <footer className="border-t border-gray-200 text-center text-xs text-gray-400 py-3">
        Alpha Lens · AI-Powered Global Investment Intelligence · Paper trading only — not financial advice
      </footer>
    </div>
  )
}
TSXEOF

echo ""
echo "============================================"
echo "  E8 MARKET RADAR — INSTALL COMPLETE"
echo "============================================"
echo ""
echo "FILES CREATED:"
echo "  backend/engines/market_radar.py   (E8 engine)"
echo "  backend/api/radar.py              (API router)"
echo "  frontend/pages/radar.tsx          (/radar page)"
echo "  scripts/add_radar_tables.sql      (DB tables)"
echo ""
echo "FILES UPDATED:"
echo "  backend/main.py        (radar router + 5-min job)"
echo "  backend/tasks/jobs.py  (run_market_radar job)"
echo "  backend/config.py      (optional paid API keys)"
echo "  frontend/components/Layout.tsx  (Radar nav link)"
echo ""
echo "NEXT STEPS:"
echo ""
echo "  1. Run in Supabase SQL Editor:"
echo "     scripts/add_radar_tables.sql"
echo ""
echo "  2. Optional — add to Replit Secrets for better data:"
echo "     UNUSUAL_WHALES_KEY   (options flow - unusualwhales.com ~\$50/mo)"
echo "     ALPHA_VANTAGE_KEY    (real-time commodities - alphavantage.co ~\$50/mo)"
echo "     FINNHUB_KEY          (news catalyst - finnhub.io free tier available)"
echo ""
echo "  3. Rebuild frontend:"
echo "     cd frontend && npm run build && cd .."
echo ""
echo "  4. Hit Run — radar scans every 5 minutes automatically"
echo ""
echo "  5. Visit /radar in your app to see the live alerts page"
echo ""
echo "  6. Test immediately:"
echo "     POST /api/radar/scan"
echo "     GET  /api/radar/alerts"
echo "     GET  /api/radar/prices"
echo "     GET  /api/radar/status"
echo ""
